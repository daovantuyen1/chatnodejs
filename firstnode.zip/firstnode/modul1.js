var temp="helo modu nhe";
module.exports=temp;